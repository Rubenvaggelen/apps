package com.gmailorg.carradio

/**
 * Alleen presentatie: het echte WhatsApp-gesprek blijft altijd de oorspronkelijke naam gebruiken,
 * zodat antwoorden naar het juiste gesprek op de telefoon gaan.
 */
object ContactAliases {
    private val aliases = linkedMapOf(
        "Beyonce aka FARQUAAD Van Aggelen" to "Dochter",
        "Susan Oehlers" to "Ma",
        "SST" to "CA",
        "Ruben Werk Tel" to "Test"
    )

    val defaultRealNames: Set<String> get() = aliases.keys

    fun displayName(realName: String): String =
        aliases.entries.firstOrNull { it.key.equals(realName.trim(), ignoreCase = true) }?.value
            ?: realName

    fun detailName(realName: String): String {
        val display = displayName(realName)
        return if (display.equals(realName, ignoreCase = true)) realName else "$display  •  $realName"
    }
}
