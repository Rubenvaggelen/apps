package com.gmailorg.hub

data class HomeTile(
    val id: String,               // "notifications" | "mail" | package name van een app
    val type: TileType,
    val label: String,
    val packageName: String? = null // alleen voor type APP
)

enum class TileType { NOTIFICATIONS, MAIL, ROUTE, HOUSEHOLD, MOVIES, PARKING, SETTINGS, ASK, RECIPES, NEWS, RADIO, CURRENCY, FINANCE, FITNESS, APP, ADD_BUTTON }
